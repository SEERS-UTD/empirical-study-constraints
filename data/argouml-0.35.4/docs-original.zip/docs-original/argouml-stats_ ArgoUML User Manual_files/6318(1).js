
;
setTimeout(function () {
  var a = document.createElement('script');
  var b = document.getElementsByTagName('script')[0];
  a.src = document.location.protocol + '//script.crazyegg.com/pages/scripts/0011/6318.js';
  a.async = true;
  a.type = 'text/javascript';
  b.parentNode.insertBefore(a, b);
}, 1);


