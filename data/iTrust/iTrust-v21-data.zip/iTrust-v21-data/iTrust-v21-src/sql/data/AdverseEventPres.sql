INSERT INTO adverseevents(id, Status, PatientMID, PresImmu, Code, Comment, Prescriber, TimeLogged) VALUES
(1, 'Active', 1, 'Prioglitazone', '647641512', 'IM DYING', 9000000000, '2009-11-09 14:26:11.0'),
(8, 'Active', 1, 'Prioglitazone', '647641512', 'IM DYING', 9000000000, '2009-11-09 14:26:11.0'),
(3, 'Active', 1, 'Prioglitazone', '647641512', 'IM DYING', 9000000000, '2009-11-09 14:26:11.0'),
(4, 'Active', 1, 'Prioglitazone', '647641512', 'IM DYING', 9000000000, '2009-01-09 14:26:11.0'),
(5, 'Active', 1, 'Prioglitazone', '647641512', 'IM DYING', 9000000000, '2002-04-09 14:26:11.0'),
(6, 'removed', 1, 'Prioglitazone', '647641512', 'IM DYING', 9000000000, '2006-11-09 14:26:11.0'),
(7, 'removed', 1, 'Prioglitazone', '647641512', 'IM DYING', 9000000000, '2009-10-09 14:26:11.0'),
(2, 'Active', 1, 'Hepatitis B', '90371', 'IM MELTING!', 9000000000, '2009-11-09 14:44:45.0');